# Signway
Sign language cross-platform app.                     -  Developed interactive lessons, a dictionary, and a recognition engine.  
